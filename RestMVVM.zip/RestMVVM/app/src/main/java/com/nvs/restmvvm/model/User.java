package com.nvs.restmvvm.model;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.nvs.restmvvm.BR;

public class User extends BaseObservable {
  private String name;
    private String email;
    private String mobile;
    private String designation;

    public User(String name, String email, String mobile, String designation) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.designation = designation;
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
    }
   @Bindable
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
        notifyPropertyChanged(BR.email);
    }
   @Bindable
    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
        notifyPropertyChanged(BR.mobile);

    }
   @Bindable
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
        notifyPropertyChanged(BR.designation);
    }
}
