package com.nvs.restmvvm;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.nvs.restmvvm.databinding.ActivityMainBinding;
import com.nvs.restmvvm.model.User;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding activityMainBinding;
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User>userList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityMainBinding= DataBindingUtil.setContentView(MainActivity.this,R.layout.activity_main);
        recyclerView=activityMainBinding.recyclerView;
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        userList=new ArrayList<>();
        userList.add(new User("bali","bali@gmail.com","9985694726","software"));
        userList.add(new User("nagoor","n@gmail.com","8885694726","software"));
        userList.add(new User("pavan","p@gmail.com","9005694752","civil"));
        userList.add(new User("eswar","e@gmail.com","7784547267","software"));
        userAdapter=new UserAdapter(userList,MainActivity.this);

        recyclerView.setAdapter(userAdapter);
     //   setContentView(R.layout.activity_main);
    }
}
