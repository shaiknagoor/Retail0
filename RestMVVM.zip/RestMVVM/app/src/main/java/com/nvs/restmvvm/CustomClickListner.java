package com.nvs.restmvvm;

import com.nvs.restmvvm.model.User;

public interface CustomClickListner {
    void cardClicked(User user);
}
