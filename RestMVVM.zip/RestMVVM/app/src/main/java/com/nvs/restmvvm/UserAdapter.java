package com.nvs.restmvvm;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.nvs.restmvvm.databinding.UserRowitemBinding;
import com.nvs.restmvvm.model.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> implements CustomClickListner{
    private List<User>userList;
    private Context mContext;
    private LayoutInflater layoutInflater;

    public UserAdapter(List<User> userList, Context mContext) {
        this.userList = userList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public UserAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if (layoutInflater == null) {
            layoutInflater = LayoutInflater.from(viewGroup.getContext());
        }
        UserRowitemBinding userRowitemBinding=DataBindingUtil.inflate(layoutInflater,R.layout.user_rowitem,viewGroup,false);

        return new MyViewHolder(userRowitemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.MyViewHolder holder, int i) {
        holder.userRowitemBinding.setUser(userList.get(i));

    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    @Override
    public void cardClicked(User user) {
        Toast.makeText(mContext,"Clicked Item is "+user.getName(),Toast.LENGTH_LONG).show();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private final UserRowitemBinding userRowitemBinding;
        public MyViewHolder(@NonNull UserRowitemBinding rowitemBinding) {
            super(rowitemBinding.getRoot());
            this.userRowitemBinding=rowitemBinding;
        }
    }
}
